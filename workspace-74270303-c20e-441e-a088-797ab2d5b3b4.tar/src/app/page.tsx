'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Wifi, 
  WifiOff, 
  Settings, 
  Plus, 
  Globe, 
  Shield, 
  Zap,
  Server,
  Clock,
  CheckCircle,
  XCircle,
  MoreVertical
} from 'lucide-react'

interface DNSProfile {
  id: string
  name: string
  primary: string
  secondary?: string
  isActive: boolean
  isDefault: boolean
  description?: string
  icon?: string
}

export default function DNSManagerApp() {
  const [dnsProfiles, setDnsProfiles] = useState<DNSProfile[]>([
    {
      id: '1',
      name: 'Google DNS',
      primary: '8.8.8.8',
      secondary: '8.8.4.4',
      isActive: true,
      isDefault: true,
      description: 'Fast and reliable DNS service',
      icon: '🌐'
    },
    {
      id: '2',
      name: 'Cloudflare DNS',
      primary: '1.1.1.1',
      secondary: '1.0.0.1',
      isActive: false,
      isDefault: false,
      description: 'Privacy-focused DNS service',
      icon: '🛡️'
    },
    {
      id: '3',
      name: 'OpenDNS',
      primary: '208.67.222.222',
      secondary: '208.67.220.220',
      isActive: false,
      isDefault: false,
      description: 'Secure DNS with filtering',
      icon: '🔒'
    }
  ])

  const [globalDnsEnabled, setGlobalDnsEnabled] = useState(true)
  const [selectedTab, setSelectedTab] = useState('profiles')

  const toggleDnsProfile = (id: string) => {
    setDnsProfiles(profiles => 
      profiles.map(profile => ({
        ...profile,
        isActive: profile.id === id ? !profile.isActive : false
      }))
    )
  }

  const toggleGlobalDns = () => {
    setGlobalDnsEnabled(!globalDnsEnabled)
    if (!globalDnsEnabled) {
      // If enabling global DNS, ensure at least one profile is active
      const hasActiveProfile = dnsProfiles.some(p => p.isActive)
      if (!hasActiveProfile && dnsProfiles.length > 0) {
        setDnsProfiles(profiles => 
          profiles.map(profile => ({
            ...profile,
            isActive: profile.id === '1'
          }))
        )
      }
    } else {
      // If disabling global DNS, deactivate all profiles
      setDnsProfiles(profiles => 
        profiles.map(profile => ({
          ...profile,
          isActive: false
        }))
      )
    }
  }

  const activeProfile = dnsProfiles.find(p => p.isActive)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Mobile App Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${globalDnsEnabled ? 'bg-green-100' : 'bg-gray-100'}`}>
                {globalDnsEnabled ? (
                  <Wifi className="w-5 h-5 text-green-600" />
                ) : (
                  <WifiOff className="w-5 h-5 text-gray-600" />
                )}
              </div>
              <div>
                <h1 className="text-lg font-semibold text-slate-900">مدیریت DNS</h1>
                <p className="text-xs text-slate-500">
                  {globalDnsEnabled ? 'فعال' : 'غیرفعال'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 max-w-md mx-auto">
        {/* Status Card */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${globalDnsEnabled ? 'bg-green-500' : 'bg-gray-400'} animate-pulse`}></div>
                <span className="text-sm font-medium">وضعیت DNS</span>
              </div>
              <Switch 
                checked={globalDnsEnabled}
                onCheckedChange={toggleGlobalDns}
              />
            </div>
            
            {globalDnsEnabled && activeProfile && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{activeProfile.icon}</span>
                  <div>
                    <p className="font-medium text-green-900">{activeProfile.name}</p>
                    <p className="text-xs text-green-700">{activeProfile.description}</p>
                  </div>
                </div>
                <div className="text-xs text-green-600 space-y-1">
                  <p>اصلی: {activeProfile.primary}</p>
                  {activeProfile.secondary && <p>ثانویه: {activeProfile.secondary}</p>}
                </div>
              </div>
            )}

            {!globalDnsEnabled && (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                <p className="text-sm text-gray-600 text-center">
                  DNS غیرفعال است. برای فعال کردن، کلید را روشن کنید.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profiles" className="text-xs">پروفایل‌ها</TabsTrigger>
            <TabsTrigger value="status" className="text-xs">وضعیت</TabsTrigger>
            <TabsTrigger value="settings" className="text-xs">تنظیمات</TabsTrigger>
          </TabsList>

          <TabsContent value="profiles" className="mt-4">
            <div className="space-y-3">
              {dnsProfiles.map((profile) => (
                <Card key={profile.id} className={`transition-all ${profile.isActive ? 'ring-2 ring-green-500 bg-green-50' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="text-2xl">{profile.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-slate-900">{profile.name}</h3>
                            {profile.isDefault && (
                              <Badge variant="secondary" className="text-xs">پیش‌فرض</Badge>
                            )}
                            {profile.isActive && (
                              <Badge variant="default" className="text-xs bg-green-600">فعال</Badge>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 mb-2">{profile.description}</p>
                          <div className="text-xs text-slate-500 space-y-1">
                            <p className="font-mono">{profile.primary}</p>
                            {profile.secondary && <p className="font-mono">{profile.secondary}</p>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleDnsProfile(profile.id)}
                          disabled={!globalDnsEnabled}
                        >
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-slate-200">
                      <Button
                        variant={profile.isActive ? "default" : "outline"}
                        size="sm"
                        className="w-full"
                        onClick={() => toggleDnsProfile(profile.id)}
                        disabled={!globalDnsEnabled}
                      >
                        {profile.isActive ? 'غیرفعال کردن' : 'فعال کردن'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Button variant="outline" className="w-full" disabled={!globalDnsEnabled}>
                <Plus className="w-4 h-4 ml-2" />
                افزودن پروفایل جدید
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="status" className="mt-4">
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    اتصال شبکه
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">وضعیت</span>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span className="text-sm font-medium">متصل</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">سرور DNS</span>
                    <span className="text-sm font-mono">{activeProfile?.primary || 'N/A'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">پاسخ‌دهی</span>
                    <span className="text-sm font-medium">12ms</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    آمار استفاده
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">درخواست‌های امروز</span>
                    <span className="text-sm font-medium">1,247</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">مسدود شده</span>
                    <span className="text-sm font-medium">23</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">آخرین به‌روزرسانی</span>
                    <span className="text-sm font-medium">۲ دقیقه پیش</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-4">
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    امنیت
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">فیلتر کردن محتوا</span>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">محافظت در برابر فیشینگ</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">مسدود کردن تبلیغات</span>
                    <Switch />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    عملکرد
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">DNS کش</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">بهینه‌سازی خودکار</span>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Server className="w-4 h-4" />
                    پیشرفته
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">DNS over HTTPS</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">DNS over TLS</span>
                    <Switch />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}